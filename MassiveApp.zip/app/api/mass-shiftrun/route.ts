import * as constants from "@/app/constants";
import { NextRequest, NextResponse } from "next/server";

//securebaseUrlprod
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const response = await fetch(
      `${constants.securebaseUrlprod}/masstelegramshiftroute`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.NEXT_PUBLIC_API_SECRET_KEY ?? "", 
        },
        body: JSON.stringify({
          stoptime: body.selectedTime,
          shift: body.reportType.trim(),
          siteStatus: body.siteStatus.trim(),
        }),
      },
    );

    if (!response.ok) {
      throw new Error(`Request failed with status: ${response.status}`);
    }

    const data = await response.json();

    return NextResponse.json(data);
  } catch (error) {
    console.error("Error:", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Unknown error" },
      { status: 500 },
    );
  }
}

