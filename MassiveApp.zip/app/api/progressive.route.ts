import * as constants from "@/app/constants";
import { ReportItem } from "@/types/schema";

export const runprogressiveShiftReport = async (
  sitedata: ReportItem,
  params: { startTime: string; endTime: string },
) => {
  try {
    const response = await fetch(
      `${constants.securebaseUrltest}/progressiveshiftroute`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": process.env.NEXT_PUBLIC_API_SECRET_KEY ?? "", 
        },
        body: JSON.stringify({
          sitedata: sitedata,
          params: params,
        }),
      },
    );

    if (!response.ok) {
      throw new Error(`Request failed with status: ${response.status}`);
    }

    const data = await response.json();

    return data;
  } catch (error) {
    console.error("Error:", error);
    throw error;
  }
};
